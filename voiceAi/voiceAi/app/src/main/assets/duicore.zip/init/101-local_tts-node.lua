require('luabin')
luabin.path = playerconf.DUICORE_HOME .. '/hybrid.lub;' .. playerconf.DATA_HOME .. '/core.lub;' .. playerconf.DUICORE_HOME .. '/corelib.lub'

local ttsnode = require 'player.node.tts'
ttsnode:run()
